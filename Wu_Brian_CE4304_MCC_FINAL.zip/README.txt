Greetings Dr.Swartz!,

This is just a short message on how appreciative I am of this course, and how much I really enjoyed it this semester.
After finishing this project (and actually getting it to work!), I felt everything click that I learned throughout
the semester, and I can confidently say that I have a strong grasp on computer architecture! 
The last minute extension really saved me, and without it I would probably have sent in an unfinished project with
both programs not working, so thank you so much for letting me experience this project fully.

Program 1 and 2 both are fully functioning:
Program 1's result is stored in data RAM at address 0x30.
Program 2's result is stored in data RAM at address 0x40.

I've included some screenshots of the signals and register values because I couldn't figure out
what to do with programOutput on the testbench to display the proper result.
In addition, the screenshots also display what's stored in memory for each program so I hope that helps with making
sure the program display the correct results!

Thank you for being such an amazing professor this semester, and though it was a struggle it truly was an enjoyable experience.

tldr; The program works!

Regards,
Brian

